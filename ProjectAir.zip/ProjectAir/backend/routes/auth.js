const express = require('express');
const router = express.Router();
const pool = require('../db');
const bcrypt = require('bcrypt');

router.post('/register', async (req, res) => {
    const { full_name, email, login, password, role = 'user' } = req.body;
    
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const result = await pool.query(
            `INSERT INTO users (full_name, email, login, password, role) 
             VALUES ($1, $2, $3, $4, $5) 
             RETURNING id, full_name, email, login, role, created_at`,
            [full_name, email, login, hashedPassword, role]
        );
        res.status(201).json({ success: true, user: result.rows[0] });
    } catch (err) {
        if (err.code === '23505') {
            res.status(400).json({ success: false, error: 'Пользователь с таким email или login уже существует' });
        } else {
            res.status(400).json({ success: false, error: err.message });
        }
    }
});

router.post('/login', async (req, res) => {
    const { login, password } = req.body;
    
    try {
        const result = await pool.query(
            `SELECT id, full_name, email, login, password, role, created_at 
             FROM users 
             WHERE login = $1 OR email = $1`,
            [login]
        );
        
        if (result.rows.length === 0) {
            return res.status(401).json({ success: false, error: 'Неверный логин/email или пароль' });
        }
        
        const user = result.rows[0];
        const validPassword = await bcrypt.compare(password, user.password);
        
        if (!validPassword) {
            return res.status(401).json({ success: false, error: 'Неверный логин/email или пароль' });
        }
        
        delete user.password;
        
        res.json({ success: true, user: user });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

router.get('/users', async (req, res) => {
    try {
        const result = await pool.query('SELECT id, full_name, email, login, role, created_at FROM users ORDER BY id');
        res.json({ success: true, users: result.rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

router.get('/profile', async (req, res) => {
    const userId = req.headers.authorization?.split(' ')[1];
    if (!userId) {
        return res.status(401).json({ success: false, error: 'не авторизован' });
    }
    try {
        const result = await pool.query(
            'SELECT id, full_name, email, login, role, created_at FROM users WHERE id = $1',
            [userId]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'пользователь не найден' });
        }
        res.json({ success: true, user: result.rows[0] });
    } catch (err) {
        console.error('ошибка get /profile:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

router.put('/profile', async (req, res) => {
    const userId = req.headers.authorization?.split(' ')[1];
    const { full_name, email, login, password } = req.body;
    if (!userId) {
        return res.status(401).json({ success: false, error: 'не авторизован' });
    }
    try {
        let query = `UPDATE users SET full_name = $1, email = $2, login = $3`;
        let params = [full_name, email, login];
        if (password && password.trim() !== '') {
            const hashedPassword = await bcrypt.hash(password, 10);
            query += `, password = $4`;
            params.push(hashedPassword);
        }
        query += ` WHERE id = $${params.length + 1} RETURNING id, full_name, email, login, role, created_at`;
        params.push(userId);
        const result = await pool.query(query, params);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'пользователь не найден' });
        }
        res.json({ success: true, user: result.rows[0] });
    } catch (err) {
        console.error('ошибка put /profile:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;