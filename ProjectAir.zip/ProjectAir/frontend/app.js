const API_URL = 'http://localhost:5000/api'; 

// ========== регистрация ==========
async function registerUser(event) {
    event.preventDefault();
    const full_name = document.getElementById('full_name').value;
    const email = document.getElementById('email').value;
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ full_name, email, login, password })
        });
        const data = await response.json();
        document.getElementById('message').textContent = data.message || data.error || 'ошибка регистрации';
        if (response.ok) {
            setTimeout(() => { window.location.href = 'login.html'; }, 1000);
        }
    } catch (error) {
        console.error('ошибка подключения:', error);
        document.getElementById('message').textContent = 'сервер недоступен';
    }
}

// ========== авторизация ==========
async function loginUser(event) {
    event.preventDefault();
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ login, password })
        });
        const data = await response.json();
        if (response.ok) {
            localStorage.setItem('user', JSON.stringify(data.user));
            document.getElementById('message').textContent = `добро пожаловать, ${data.user.full_name}`;
            setTimeout(() => { window.location.href = 'index.html'; }, 1000);
        } else {
            document.getElementById('message').textContent = data.message || data.error || 'ошибка входа';
        }
    } catch (error) {
        console.error('ошибка подключения:', error);
        document.getElementById('message').textContent = 'сервер недоступен';
    }
}

// ========== проверка авторизации ==========
function getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

function requireAuth() {
    const user = getCurrentUser();
    if (!user) {
        alert('сначала войдите в систему');
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// ========== показ информации о пользователе ==========
function showUserInfo() {
    const userBlock = document.getElementById('user-info');
    if (!userBlock) return;
    const user = getCurrentUser();
    if (user) {
        userBlock.innerHTML = `
            <p><strong>пользователь:</strong> ${user.full_name}</p>
            <p><strong>роль:</strong> ${user.role}</p>
            <button onclick="logout()">выйти</button>
        `;
    } else {
        userBlock.innerHTML = `<p>вы не авторизованы</p>`;
    }
}

// ========== загрузка героев с фото ==========
async function loadHeroes() {
    try {
        const response = await fetch(`${API_URL}/heroes`);
        const data = await response.json();
        if (!data.success) throw new Error(data.error || 'ошибка загрузки героев');
        const heroes = data.heroes;
        const container = document.getElementById('heroes-list');
        if (!container) return;
        container.innerHTML = '';
        heroes.forEach((hero) => {
            let imagePath = hero.image_url;
            if (!imagePath) {
                if (hero.id === 1) imagePath = '/маления.jpg';
                else if (hero.id === 2) imagePath = '/радан.jpg';
                else if (hero.id === 3) imagePath = '/ренни.jpg';
                else imagePath = '/маления.jpg';
            }
            container.innerHTML += `
                <div class="cart">
                    <img class="cart-img" src="${imagePath}" alt="${hero.title}" onerror="this.src='/маления.jpg'">
                    <h3>${hero.title}</h3>
                    <p><strong>описание:</strong> ${hero.description || 'описание отсутствует'}</p>
                    <p><strong>автор:</strong> ${hero.author || 'неизвестен'}</p>
                </div>
            `;
        });
    } catch (error) {
        console.error('ошибка загрузки героев:', error);
        const container = document.getElementById('heroes-list');
        if (container) container.innerHTML = '<p>не удалось загрузить героев</p>';
    }
}

// ========== загрузка достижений ==========
async function loadAchievements() {
    try {
        const response = await fetch(`${API_URL}/achievements`);
        const data = await response.json();
        if (!data.success) throw new Error(data.error || 'ошибка загрузки достижений');
        const achievements = data.achievements;
        const list = document.getElementById('achievements-list');
        if (!list) return;
        list.innerHTML = '';
        achievements.forEach((item) => {
            list.innerHTML += `<li>${item.name}</li>`;
        });
    } catch (error) {
        console.error('ошибка загрузки достижений:', error);
        const list = document.getElementById('achievements-list');
        if (list) list.innerHTML = '<li>не удалось загрузить данные</li>';
    }
}

// ========== загрузка профиля ==========
async function loadProfile() {
    const user = getCurrentUser();
    if (!user) {
        const profileDiv = document.getElementById('profile-data');
        if (profileDiv) {
            profileDiv.innerHTML = '<p>вы не вошли в систему</p><a href="login.html">войти</a>';
        }
        return;
    }
    try {
        const response = await fetch(`${API_URL}/auth/profile`, {
            headers: { 'Authorization': `Bearer ${user.id}` }
        });
        const data = await response.json();
        if (data.success) {
            const profileDiv = document.getElementById('profile-data');
            profileDiv.innerHTML = `
                <p><strong>полное имя:</strong> ${data.user.full_name}</p>
                <p><strong>почта:</strong> ${data.user.email}</p>
                <p><strong>логин:</strong> ${data.user.login}</p>
                <p><strong>роль:</strong> ${data.user.role}</p>
                <p><strong>дата регистрации:</strong> ${new Date(data.user.created_at).toLocaleDateString()}</p>
            `;
            if (document.getElementById('profile-fullname')) {
                document.getElementById('profile-fullname').value = data.user.full_name;
                document.getElementById('profile-email').value = data.user.email;
                document.getElementById('profile-login').value = data.user.login;
            }
        }
    } catch (error) {
        console.error('ошибка загрузки профиля:', error);
        const profileDiv = document.getElementById('profile-data');
        if (profileDiv) profileDiv.innerHTML = '<p>не удалось загрузить профиль</p>';
    }
}

// ========== обновление профиля ==========
async function updateProfile(event) {
    event.preventDefault();
    const user = getCurrentUser();
    if (!user) {
        alert('сначала войдите в систему');
        window.location.href = 'login.html';
        return;
    }
    const full_name = document.getElementById('profile-fullname').value;
    const email = document.getElementById('profile-email').value;
    const login = document.getElementById('profile-login').value;
    const password = document.getElementById('profile-password').value;
    try {
        const response = await fetch(`${API_URL}/auth/profile`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${user.id}`
            },
            body: JSON.stringify({ full_name, email, login, password: password || undefined })
        });
        const data = await response.json();
        const messageDiv = document.getElementById('profile-message');
        if (response.ok) {
            const updatedUser = { ...user, full_name, email, login };
            localStorage.setItem('user', JSON.stringify(updatedUser));
            messageDiv.style.color = '#4caf50';
            messageDiv.textContent = 'данные успешно обновлены';
            setTimeout(() => { loadProfile(); messageDiv.textContent = ''; }, 1500);
        } else {
            messageDiv.style.color = '#ff6b6b';
            messageDiv.textContent = data.error || 'ошибка обновления';
        }
    } catch (error) {
        console.error('ошибка обновления профиля:', error);
        const messageDiv = document.getElementById('profile-message');
        messageDiv.style.color = '#ff6b6b';
        messageDiv.textContent = 'сервер недоступен';
    }
}

// ========== автозагрузка при загрузке страницы ==========
document.addEventListener('DOMContentLoaded', () => {
    showUserInfo();
    if (document.getElementById('heroes-list')) loadHeroes();
    if (document.getElementById('achievements-list')) loadAchievements();
    if (document.getElementById('profile-data')) loadProfile();
});