const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/achievements', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM achievements ORDER BY id');
        res.json({ success: true, achievements: result.rows });
    } catch (err) {
        console.error('ошибка get /achievements:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;