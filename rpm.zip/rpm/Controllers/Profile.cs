﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace rpm.Controllers
{
    public class Profile : Controller
    {
        private static List<UserData> users = new List<UserData>(); 
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string name, string email, int age)
        {
            var userData = new UserData
            {
                Name = name,
                Email = email,
                Age = age
            };
            users.Add(userData);
            return RedirectToAction("Display");         
        }

        public IActionResult Display() 
        {
            return View(users);
        }
    }
    public class UserData
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
    }
}
