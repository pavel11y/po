﻿using Microsoft.AspNetCore.Mvc;

namespace rpm.Controllers
{
    public class InfoController : Controller
    {
        public IActionResult Page()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        } 
    }
}
