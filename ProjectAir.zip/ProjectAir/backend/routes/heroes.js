const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/heroes', async (req, res) => {
    try {
        const query = `
            SELECT 
                h.id, 
                h.title, 
                h.description, 
                h.user_id,
                h.created_at,
                u.full_name as author,
                u.login as author_login,
                COALESCE(
                    json_agg(DISTINCT jsonb_build_object(
                        'id', a.id,
                        'name', a.name
                    )) FILTER (WHERE a.id IS NOT NULL), 
                    '[]'::json
                ) as achievements
            FROM heroes h
            LEFT JOIN users u ON h.user_id = u.id
            LEFT JOIN hero_achievements ha ON h.id = ha.hero_id
            LEFT JOIN achievements a ON ha.achievement_id = a.id
            GROUP BY h.id, u.id, u.full_name, u.login
            ORDER BY h.id
        `;
        
        const result = await pool.query(query);
        res.json({ success: true, heroes: result.rows });
    } catch (err) {
        console.error('Ошибка GET /heroes:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

router.get('/heroes/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const query = `
            SELECT 
                h.id, 
                h.title, 
                h.description, 
                h.user_id,
                h.created_at,
                u.full_name as author,
                u.login as author_login,
                COALESCE(
                    json_agg(DISTINCT jsonb_build_object(
                        'id', a.id,
                        'name', a.name
                    )) FILTER (WHERE a.id IS NOT NULL), 
                    '[]'::json
                ) as achievements
            FROM heroes h
            LEFT JOIN users u ON h.user_id = u.id
            LEFT JOIN hero_achievements ha ON h.id = ha.hero_id
            LEFT JOIN achievements a ON ha.achievement_id = a.id
            WHERE h.id = $1
            GROUP BY h.id, u.id, u.full_name, u.login
        `;
        
        const result = await pool.query(query, [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Герой не найден' });
        }
        
        res.json({ success: true, hero: result.rows[0] });
    } catch (err) {
        console.error('Ошибка GET /heroes/:id:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

router.post('/heroes', async (req, res) => {
    const { title, description, user_id } = req.body;
    
    try {
        const result = await pool.query(
            `INSERT INTO heroes (title, description, user_id) 
             VALUES ($1, $2, $3) 
             RETURNING *`,
            [title, description, user_id]
        );
        
        res.status(201).json({ success: true, hero: result.rows[0] });
    } catch (err) {
        console.error('Ошибка POST /heroes:', err.message);
        res.status(400).json({ success: false, error: err.message });
    }
});

router.post('/heroes/:id/achievements', async (req, res) => {
    const { id } = req.params;
    const { achievement_id } = req.body;
    
    try {
        await pool.query(
            `INSERT INTO hero_achievements (hero_id, achievement_id) 
             VALUES ($1, $2) 
             ON CONFLICT DO NOTHING`,
            [id, achievement_id]
        );
        
        res.json({ success: true, message: 'Достижение добавлено' });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

module.exports = router;